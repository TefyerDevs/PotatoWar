package net.mcreator.potatowar.procedures;

import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

public class MilitaryTextProcedure {
	public static String execute() {
		double RandomNum = 0;
		RandomNum = Mth.nextInt(RandomSource.create(), 1, 1);
		if (RandomNum == 1) {
			return MilitaryTextCluster1Procedure.execute();
		}
		return "Error#9";
	}
}
