package net.mcreator.potatowar.procedures;

public class BuildersFatiugeEffectExpiresProcedure {
	public static void execute() {
	}
}
